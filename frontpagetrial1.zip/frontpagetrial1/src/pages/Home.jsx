import React from 'react';
import Navbar from '../components/sheesh/Navbar';
import HeroSection from '../components/sheesh/HeroSection';
import FeaturedMenu from '../components/sheesh/FeaturedMenu';
import AboutSection from '../components/sheesh/AboutSection';
import OrderSection from '../components/sheesh/OrderSection';
import GallerySection from '../components/sheesh/GallerySection';
import SpiceSection from '../components/sheesh/SpiceSection';
import CateringSection from '../components/sheesh/CateringSection';
import ReviewsSection from '../components/sheesh/ReviewsSection';
import Footer from '../components/sheesh/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <FeaturedMenu />
      <AboutSection />
      <OrderSection />
      <GallerySection />
      <SpiceSection />
      <CateringSection />
      <ReviewsSection />
      <Footer />
    </div>
  );
}