import React, { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight, Plus } from 'lucide-react';

const dishes = [
  {
    name: 'Falafel Bowl',
    price: '$12.50',
    desc: 'Crispy falafel, hummus, pickled turnips, cucumber, tahini over rice or greens',
    img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/a6ce8975e_generated_image.png',
    tags: [{ label: '🌱 Vegan', color: 'bg-green-50 text-green-700' }, { label: 'GF Option', color: 'bg-orange-50 text-orange-600' }],
    badge: { label: 'Fan Fave', color: 'bg-brand text-white' },
  },
  {
    name: 'Shawarma Wrap',
    price: '$13.50',
    desc: 'Marinated chicken, garlic sauce, pickles, crispy fries in warm lavash',
    img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/5f0033b27_generated_image.png',
    tags: [{ label: '💪 High Protein', color: 'bg-amber-50 text-amber-700' }],
    badge: { label: '🔥 Spicy', color: 'bg-red-500 text-white' },
  },
  {
    name: 'Harissa Bowl',
    price: '$14.00',
    desc: "Spicy harissa chicken, roasted veggies, quinoa, feta, za'atar yogurt",
    img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/c0756d269_generated_image.png',
    tags: [{ label: '🌶 Spicy', color: 'bg-red-50 text-red-600' }, { label: '💪 High Protein', color: 'bg-amber-50 text-amber-700' }],
    badge: { label: 'New', color: 'bg-emerald-500 text-white' },
  },
  {
    name: 'Mezze Plate',
    price: '$11.00',
    desc: 'Hummus, baba ganoush, tzatziki, falafel, pita, olives — perfect to share',
    img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/e322dac4d_generated_image.png',
    tags: [{ label: '🥗 Vegetarian', color: 'bg-green-50 text-green-700' }],
    badge: null,
  },
  {
    name: 'Kafta Plate',
    price: '$15.50',
    desc: 'Seasoned beef & lamb kebabs with saffron rice, salad, hummus and pita',
    img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/e73105c05_generated_image.png',
    tags: [{ label: '💪 High Protein', color: 'bg-amber-50 text-amber-700' }],
    badge: null,
  },
];

function DishCard({ dish, index, onAdd }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="group shrink-0 w-[240px] sm:w-[260px] bg-white rounded-[1.75rem] overflow-hidden border border-[#F0F0F0] cursor-pointer"
      style={{ boxShadow: '0 2px 16px rgba(0,0,0,0.06)' }}
      whileHover={{ y: -4, boxShadow: '0 12px 40px rgba(0,0,0,0.12)' }}
      transition2={{ duration: 0.2 }}
      onClick={() => onAdd(dish.name)}
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-surface">
        <img src={dish.img} alt={dish.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.06]" />
        {dish.badge && (
          <span className={`absolute top-3 left-3 ${dish.badge.color} text-[10px] font-bold tracking-wide uppercase px-2.5 py-1 rounded-full`}>
            {dish.badge.label}
          </span>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onAdd(dish.name); }}
          className="absolute bottom-3 right-3 w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-brand hover:text-white">
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <div className="p-4 pb-5">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="font-display font-bold text-[15px] text-[#0D0D0D]">{dish.name}</h3>
          <span className="text-brand font-bold text-[15px] shrink-0">{dish.price}</span>
        </div>
        <p className="text-[12.5px] text-[#888] leading-relaxed mb-3">{dish.desc}</p>
        <div className="flex flex-wrap gap-1.5">
          {dish.tags.map(t => (
            <span key={t.label} className={`${t.color} text-[10px] font-bold uppercase tracking-wide px-2.5 py-0.5 rounded-full`}>
              {t.label}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export default function FeaturedDishes({ onToast }) {
  const headerRef = useRef(null);
  const inView = useInView(headerRef, { once: true });

  return (
    <section id="menu" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div ref={headerRef}
          initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="flex items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-brand text-[11px] font-bold tracking-widest uppercase block mb-2">Fan Favorites</span>
            <h2 className="font-display font-bold text-[#0D0D0D] leading-tight"
              style={{ fontSize: 'clamp(1.6rem, 4vw, 2.4rem)' }}>
              Build Your<br className="sm:hidden" /> Perfect Meal
            </h2>
          </div>
          <a href="#menu" className="flex items-center gap-1.5 text-brand hover:text-brand-dark text-sm font-bold transition-colors shrink-0">
            Full Menu <ArrowRight className="w-4 h-4" />
          </a>
        </motion.div>

        {/* Horizontal scroll */}
        <div className="overflow-x-auto -mx-5 px-5 sm:-mx-8 sm:px-8 pb-4"
          style={{ scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch' }}>
          <div className="flex gap-4 w-max">
            {dishes.map((d, i) => (
              <DishCard key={d.name} dish={d} index={i} onAdd={onToast} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}