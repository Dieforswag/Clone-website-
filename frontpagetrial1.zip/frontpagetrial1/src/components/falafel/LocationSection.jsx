import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { MapPin, Clock, Phone, ShoppingBag } from 'lucide-react';

const locations = [
  { name: 'Downtown — Main St', address: '123 Main St, Suite A', hours: 'Mon–Sat 11AM–10PM · Sun 12–9PM', phone: '(555) 234-5678' },
  { name: 'Midtown — 5th Ave', address: '456 5th Ave', hours: 'Mon–Sat 11AM–10PM · Sun 12–9PM', phone: '(555) 234-5681' },
  { name: 'Westside — Market Blvd', address: '789 Market Blvd', hours: 'Mon–Sat 11AM–9PM · Sun 12–8PM', phone: '(555) 234-5682' },
];

export default function LocationsSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  return (
    <section id="locations" className="py-16 sm:py-20 bg-surface">
      <div ref={ref} className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-10">
          <span className="text-brand text-[11px] font-bold tracking-widest uppercase block mb-2">Find Us</span>
          <h2 className="font-display font-bold text-[#0D0D0D] tracking-tight"
            style={{ fontSize: 'clamp(1.6rem, 4vw, 2.4rem)' }}>
            Our Locations
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-3 gap-4">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.name}
              initial={{ opacity: 0, y: 24 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white rounded-[1.75rem] p-5 sm:p-6 border border-[#F0F0F0] hover:shadow-card-hover transition-shadow duration-300">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 bg-brand-light rounded-[0.875rem] flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-4.5 h-4.5 text-brand" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-[14.5px] text-[#0D0D0D]">{loc.name}</h3>
                  <p className="text-[12px] text-[#999] mt-0.5">{loc.address}</p>
                </div>
              </div>
              <div className="space-y-2 mb-5 pl-1">
                <div className="flex items-start gap-2 text-[12.5px] text-[#666]">
                  <Clock className="w-3.5 h-3.5 text-[#AAA] mt-0.5 shrink-0" />
                  {loc.hours}
                </div>
                <div className="flex items-center gap-2 text-[12.5px] text-[#666]">
                  <Phone className="w-3.5 h-3.5 text-[#AAA] shrink-0" />
                  {loc.phone}
                </div>
              </div>
              <a href="#menu"
                className="inline-flex items-center gap-2 bg-brand hover:bg-brand-dark text-white text-[12px] font-bold px-5 py-2.5 rounded-full transition-all duration-200">
                <ShoppingBag className="w-3.5 h-3.5" /> Order Here
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}