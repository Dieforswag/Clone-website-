import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const FEAST = 'https://media.base44.com/images/public/6a007691428801536fd594d0/87a05d4db_generated_image.png';
const FALAFEL = 'https://media.base44.com/images/public/6a007691428801536fd594d0/a6ce8975e_generated_image.png';
const SHAWARMA = 'https://media.base44.com/images/public/6a007691428801536fd594d0/5f0033b27_generated_image.png';
const HARISSA = 'https://media.base44.com/images/public/6a007691428801536fd594d0/c0756d269_generated_image.png';
const MEZZE = 'https://media.base44.com/images/public/6a007691428801536fd594d0/e322dac4d_generated_image.png';

const items = [
  { src: FEAST, label: 'The Grand Spread', span: 'col-span-2 row-span-2 min-h-[280px]' },
  { src: FALAFEL, label: 'Falafel Bowl', span: '' },
  { src: SHAWARMA, label: 'Shawarma Wrap', span: '' },
  { src: HARISSA, label: 'Harissa Bowl', span: '' },
  { src: MEZZE, label: 'Mezze Plate', span: '' },
];

export default function GallerySection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  return (
    <section className="py-16 sm:py-20 bg-surface">
      <div ref={ref} className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
          className="text-center mb-8">
          <span className="text-brand text-[11px] font-bold tracking-widest uppercase block mb-2">The Spread</span>
          <h2 className="font-display font-bold text-[#0D0D0D] tracking-tight"
            style={{ fontSize: 'clamp(1.6rem, 4vw, 2.4rem)' }}>
            Eat With Your Eyes First
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 sm:gap-3 auto-rows-[160px] sm:auto-rows-[200px]">
          {items.map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.45, delay: i * 0.07 }}
              className={`${item.span} group relative rounded-[1.5rem] overflow-hidden cursor-pointer`}>
              <img src={item.src} alt={item.label}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4 sm:p-5">
                <span className="text-white font-display font-bold text-sm sm:text-base">{item.label}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}