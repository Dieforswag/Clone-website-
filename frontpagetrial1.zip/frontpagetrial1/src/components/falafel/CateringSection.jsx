import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Check, Mail } from 'lucide-react';

const CATERING_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/c7fa82bf0_generated_image.png';

const perks = [
  'Serves 10 to 500+ people',
  'Dietary accommodations included',
  'Free delivery on orders $200+',
];

export default function CateringSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  return (
    <section id="catering" className="py-16 sm:py-20 bg-white">
      <div ref={ref} className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="grid lg:grid-cols-2 overflow-hidden rounded-[2rem] border border-[#F0F0F0] bg-surface"
          style={{ boxShadow: '0 2px 16px rgba(0,0,0,0.06)' }}>
          <div className="relative min-h-[240px] lg:min-h-0">
            <img src={CATERING_IMG} alt="Catering spread" className="w-full h-full object-cover" />
          </div>
          <div className="p-8 sm:p-10 lg:p-12 flex flex-col justify-center">
            <span className="text-brand text-[11px] font-bold tracking-widest uppercase block mb-2">Catering</span>
            <h2 className="font-display font-bold text-[#0D0D0D] tracking-tight leading-tight mb-3"
              style={{ fontSize: 'clamp(1.7rem, 3.5vw, 2.4rem)' }}>
              Feed the<br />Whole Team
            </h2>
            <p className="text-[#4D4D4D] text-[15px] leading-relaxed mb-5">
              Office lunch, birthday, or wedding? Choose from boxed lunches, 
              buffet spreads, or custom build-your-own bar setups.
            </p>
            <ul className="space-y-3 mb-7">
              {perks.map(p => (
                <li key={p} className="flex items-center gap-3 text-sm text-[#4D4D4D]">
                  <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                  </div>
                  {p}
                </li>
              ))}
            </ul>
            <a href="mailto:hello@falafelandco.com"
              className="inline-flex items-center gap-2 bg-brand hover:bg-brand-dark text-white text-sm font-bold px-7 py-3.5 rounded-full transition-all duration-200 w-fit hover:shadow-brand">
              <Mail className="w-4 h-4" /> Inquire Now
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}