import React from 'react';
import { Flame, Instagram, Facebook, Twitter, Clock, Phone, Mail } from 'lucide-react';

const col1 = ['Order Online', 'Menu', 'Catering', 'Gift Cards'];
const col2 = ['Our Story', 'Careers', 'Press', 'Franchise'];
const col3 = ['Downtown', 'Midtown', 'Westside'];

export default function Footer() {
  return (
    <footer className="bg-[#0D0D0D] text-white pt-14 pb-6">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">

        {/* Top grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-10">
          {/* Brand */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <a href="#" className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 bg-brand rounded-xl flex items-center justify-center">
                <Flame className="w-4.5 h-4.5 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-display font-bold text-base">Falafel<span className="text-brand">&</span>Co.</span>
            </a>
            <p className="text-[12px] text-white/40 leading-relaxed max-w-[200px] mb-4">
              Fresh Mediterranean, made your way. Real ingredients, zero shortcuts.
            </p>
            <div className="flex gap-2">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a key={i} href="#"
                  className="w-8 h-8 bg-white/8 hover:bg-brand rounded-xl flex items-center justify-center transition-colors duration-200">
                  <Icon className="w-3.5 h-3.5" />
                </a>
              ))}
            </div>
          </div>

          {/* Nav cols */}
          {([['Order', col1], ['Company', col2], ['Locations', col3]]).map(([title, links]) => (
            <div key={title}>
              <h4 className="text-[9.5px] font-bold tracking-widest uppercase text-white/35 mb-3.5">{title}</h4>
              <ul className="space-y-2.5">
                {links.map(link => (
                  <li key={link}><a href="#" className="text-[12.5px] text-white/50 hover:text-white transition-colors">{link}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Info bar */}
        <div className="border-t border-white/8 pt-6 mb-6">
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { icon: Clock, main: 'Mon–Sat: 11AM–10PM', sub: 'Sunday: 12PM–9PM' },
              { icon: Phone, main: '(555) 234-5678', sub: 'Catering: (555) 234-5680' },
              { icon: Mail, main: 'hello@falafelandco.com', sub: 'We reply within 24 hours' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <item.icon className="w-4 h-4 text-brand shrink-0" />
                <div>
                  <div className="text-[12.5px] font-medium text-white/80">{item.main}</div>
                  <div className="text-[11px] text-white/35">{item.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/8 pt-5 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-[10.5px] text-white/25">© 2025 Falafel & Co. All rights reserved.</p>
          <div className="flex gap-5">
            {['Privacy Policy', 'Terms', 'Accessibility'].map(l => (
              <a key={l} href="#" className="text-[10.5px] text-white/25 hover:text-white/60 transition-colors">{l}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}