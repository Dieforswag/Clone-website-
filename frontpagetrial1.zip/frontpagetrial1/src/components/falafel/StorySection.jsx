import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const KITCHEN_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/8c9bc2b23_generated_image.png';
const FALAFEL_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/72f0b69df_generated_image.png';

const stats = [
  { value: '12', label: 'Years Open' },
  { value: '3', label: 'Locations' },
  { value: '0', label: 'Freezers' },
];

export default function StorySection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section id="story" className="py-16 sm:py-24 bg-white">
      <div ref={ref} className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Images */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="relative">
            <div className="rounded-[2rem] overflow-hidden aspect-[4/3] shadow-card">
              <img src={KITCHEN_IMG} alt="Our kitchen" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-5 -right-4 sm:-right-6 w-36 sm:w-48 h-36 sm:h-48 rounded-[1.5rem] overflow-hidden border-4 border-white shadow-card-hover">
              <img src={FALAFEL_IMG} alt="Fresh falafel" className="w-full h-full object-cover" />
            </div>
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}>
            <span className="text-brand text-[11px] font-bold tracking-widest uppercase block mb-3">Our Story</span>
            <h2 className="font-display font-bold tracking-tight text-[#0D0D0D] leading-[1.1] mb-5"
              style={{ fontSize: 'clamp(1.8rem, 4vw, 2.8rem)' }}>
              Real Food,<br />Real Simple.
            </h2>
            <p className="text-[#4D4D4D] text-[15px] leading-relaxed mb-4">
              We started with one belief: everyone deserves fresh, flavorful Mediterranean food — 
              without the wait or premium price tag. Our recipes come from family kitchens across 
              Lebanon, Israel, and Palestine, reimagined for your lunch break.
            </p>
            <p className="text-[#4D4D4D] text-[15px] leading-relaxed mb-8">
              Every morning, we prep from scratch. Falafel is fried to order. 
              Pita is baked hourly. No microwaves, no freezers, no compromises.
            </p>

            <div className="grid grid-cols-3 gap-3">
              {stats.map(s => (
                <div key={s.label} className="bg-surface rounded-[1.25rem] p-4 text-center border border-[#EFEFEF]">
                  <div className="font-display font-bold text-3xl text-brand">{s.value}</div>
                  <div className="text-[11px] text-[#888] font-medium mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
