import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const SPICES_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/2c38e5dbf_generated_89ec7ae9.png';
const INTERIOR_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/f0886ccdd_generated_50de15a9.png';

export default function AboutSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="story" className="relative py-24 md:py-36">
      {/* Full-bleed charcoal grill background */}
      <div className="absolute inset-0 bg-card" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9 }}
          className="grid lg:grid-cols-2 gap-16 lg:gap-20 items-center"
        >
          {/* Text */}
          <div>
            <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">Our Story</span>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 mb-8 leading-tight">
              Where Flavor<br />
              Meets <span className="italic font-normal text-secondary">Culture</span>
            </h2>
            <div className="space-y-6 text-muted-foreground text-lg leading-[1.8] font-body">
              <p>
                At Sheesh Grill, we offer more than just delicious food — we deliver a full 
                cultural experience. Our warm and inviting space blends modern comfort with 
                Middle Eastern tradition.
              </p>
              <p>
                Every dish is crafted using time-honored recipes and the finest ingredients, 
                delivering bold spices, vibrant herbs, and a freshness you can savor. From 
                the first bite to the last, experience a perfect balance of tradition and innovation.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-12 border-t border-border/30">
              <div>
                <span className="font-display text-3xl md:text-4xl font-bold text-primary">100%</span>
                <p className="text-sm text-muted-foreground mt-1 font-body">Heart Healthy</p>
              </div>
              <div>
                <span className="font-display text-3xl md:text-4xl font-bold text-foreground">Fresh</span>
                <p className="text-sm text-muted-foreground mt-1 font-body">Daily Prepared</p>
              </div>
              <div>
                <span className="font-display text-3xl md:text-4xl font-bold text-foreground">2</span>
                <p className="text-sm text-muted-foreground mt-1 font-body">Locations in VA</p>
              </div>
            </div>
          </div>

          {/* Images */}
          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative z-10"
            >
              <img
                src={INTERIOR_IMG}
                alt="Sheesh Grill interior"
                className="w-full aspect-[4/5] object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="absolute -bottom-12 -left-8 w-48 md:w-64 z-20 hidden md:block"
            >
              <img
                src={SPICES_IMG}
                alt="Middle Eastern spices"
                className="w-full aspect-square object-cover border-4 border-background shadow-2xl"
              />
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}