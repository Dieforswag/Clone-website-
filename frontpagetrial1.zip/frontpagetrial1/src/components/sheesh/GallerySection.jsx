import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const galleryImages = [
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/7159c9347_generated_f864de9a.png', alt: 'Chicken kabob platter with rice and salad', span: 'col-span-1 row-span-1' },
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/d5356a95c_generated_392c451f.png', alt: 'Beef kubideh with saffron rice', span: 'col-span-1 row-span-2' },
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/a00ccbf12_generated_4f15bf45.png', alt: 'Gyro wrap sliced with fresh vegetables', span: 'col-span-1 row-span-1' },
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/aaac381e9_generated_e1708b2a.png', alt: 'Golden falafel with tahini sauce', span: 'col-span-1 row-span-1' },
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/d87792d17_generated_41224f1f.png', alt: 'Chicken shawarma from rotisserie', span: 'col-span-1 row-span-1' },
  { src: 'https://media.base44.com/images/public/6a007691428801536fd594d0/68067822b_generated_d27eac87.png', alt: 'Salmon kabob on the grill', span: 'col-span-1 row-span-1' },
];

function GalleryImage({ item, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-30px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={inView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.6, delay: index * 0.08 }}
      className={`${item.span} group relative overflow-hidden`}
    >
      <img
        src={item.src}
        alt={item.alt}
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-background/0 group-hover:bg-background/30 transition-all duration-500" />
    </motion.div>
  );
}

export default function GallerySection() {
  const headerRef = useRef(null);
  const headerInView = useInView(headerRef, { once: true });

  return (
    <section id="gallery" className="py-24 md:py-32 px-6 lg:px-10 max-w-7xl mx-auto">
      <motion.div
        ref={headerRef}
        initial={{ opacity: 0, y: 30 }}
        animate={headerInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
        className="text-center mb-16"
      >
        <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">Gallery</span>
        <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 leading-tight">
          Taste the Tradition<br />
          <span className="italic font-normal text-secondary">Through Every Shot</span>
        </h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto mt-6 leading-relaxed font-body">
          From freshly grilled specialties to colorful, wholesome sides — 
          our gallery brings our kitchen to life.
        </p>
      </motion.div>

      <div className="ember-line mb-16" />

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 auto-rows-[200px] md:auto-rows-[280px]">
        {galleryImages.map((item, i) => (
          <GalleryImage key={i} item={item} index={i} />
        ))}
      </div>
    </section>
  );
}