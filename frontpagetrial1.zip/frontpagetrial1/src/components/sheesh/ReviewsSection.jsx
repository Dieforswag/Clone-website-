import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    name: 'Bezhan S.',
    text: 'Absolutely delicious! The chicken kebab was perfectly grilled—juicy on the inside with a nice char on the outside. The seasoning was spot-on, with just the right balance of spices. Every bite was tender and flavorful.',
    rating: 5,
  },
  {
    name: 'Sydney S.',
    text: 'Amazing experience! Their chicken kabobs are delicious and their chickpeas are better than any other kabob place I\'ve ever tasted! The owner was even nice enough to come over to ask how we enjoyed the food. 10/10!',
    rating: 5,
  },
  {
    name: 'Farooq K.',
    text: 'Since I\'ve been in the US I haven\'t been able to have food this delicious. 5 stars to the cook and special thanks for guiding us to get the best meal.',
    rating: 5,
  },
];

function ReviewCard({ review, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.15 }}
      className="relative bg-card border border-border/30 p-8 md:p-10"
    >
      <Quote className="w-8 h-8 text-primary/30 mb-6" />
      
      <div className="flex gap-1 mb-4">
        {Array.from({ length: review.rating }).map((_, i) => (
          <Star key={i} className="w-4 h-4 fill-primary text-primary" />
        ))}
      </div>

      <p className="text-foreground text-base leading-[1.8] font-body mb-6">
        "{review.text}"
      </p>

      <div className="flex items-center gap-3 pt-6 border-t border-border/20">
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
          <span className="text-primary font-display font-bold text-lg">
            {review.name[0]}
          </span>
        </div>
        <div>
          <p className="font-display font-semibold text-foreground">{review.name}</p>
          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">Verified Guest</p>
        </div>
      </div>
    </motion.div>
  );
}

export default function ReviewsSection() {
  const headerRef = useRef(null);
  const headerInView = useInView(headerRef, { once: true });

  return (
    <section id="reviews" className="py-24 md:py-32 px-6 lg:px-10 max-w-7xl mx-auto">
      <motion.div
        ref={headerRef}
        initial={{ opacity: 0, y: 30 }}
        animate={headerInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
        className="text-center mb-16"
      >
        <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">Testimonials</span>
        <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 leading-tight">
          What Our Guests<br />
          <span className="italic font-normal text-secondary">Are Saying</span>
        </h2>
      </motion.div>

      <div className="ember-line mb-16" />

      <div className="grid md:grid-cols-3 gap-6 md:gap-8">
        {reviews.map((review, i) => (
          <ReviewCard key={i} review={review} index={i} />
        ))}
      </div>
    </section>
  );
}