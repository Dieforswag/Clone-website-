import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const SPICES_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/2c38e5dbf_generated_89ec7ae9.png';

export default function SpiceSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="relative py-16 md:py-24 bg-card overflow-hidden">
      <div ref={ref} className="max-w-7xl mx-auto px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 1 }}
          className="grid md:grid-cols-2 gap-10 items-center"
        >
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={SPICES_IMG}
              alt="Middle Eastern spices falling through dramatic light"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex flex-col justify-center">
            <div className="w-16 h-px bg-primary mb-8" />
            <p className="font-display text-2xl md:text-3xl italic text-secondary leading-relaxed">
              "Spices and herbs are at the heart of our cuisine, adding flavor 
              and nourishment with every dish we serve."
            </p>
            <div className="mt-8">
              <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground font-body">
                Open Daily
              </p>
              <p className="font-display text-xl text-foreground mt-1">
                11:00 AM — 9:00 PM
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}