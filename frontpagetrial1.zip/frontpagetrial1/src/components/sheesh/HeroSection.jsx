import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';

const HERO_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/f25df9b03_generated_6b26ac4d.png';

export default function HeroSection() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);

  const handleMouseMove = (e) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x: x * 20, y: y * 15 });
  };

  return (
    <section
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative h-screen w-full overflow-hidden flex items-end"
    >
      {/* Background Image with Parallax */}
      <motion.div
        animate={{ x: mousePos.x, y: mousePos.y }}
        transition={{ type: 'spring', stiffness: 50, damping: 30 }}
        className="absolute inset-[-40px]"
      >
        <img
          src={HERO_IMG}
          alt="Perfectly charred Mediterranean skewer"
          className="w-full h-full object-cover"
        />
      </motion.div>

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
      <div className="absolute inset-0 bg-gradient-to-r from-background/70 via-transparent to-transparent" />

      {/* Vertical Anchor Text */}
      <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 z-10">
        <span className="text-[11px] uppercase tracking-[0.4em] text-muted-foreground/50 font-body rotate-90 block whitespace-nowrap origin-center"
          style={{ writingMode: 'vertical-rl' }}>
          Est. 2024 — Falls Church, VA
        </span>
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 lg:px-10 pb-20 md:pb-28">
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="text-primary text-sm uppercase tracking-[0.3em] font-body mb-4">
            Authentic Mediterranean Cuisine
          </p>
          <h1 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-bold leading-[0.9] tracking-tight mb-6">
            A Fresh Take
            <br />
            <span className="text-primary">On Heart-Healthy</span>
            <br />
            <span className="italic font-normal text-secondary">Dining</span>
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl max-w-xl leading-relaxed font-body mb-10">
            Step into Sheesh Grill, where bold Middle Eastern flavors meet 
            100% heart-healthy Mediterranean ingredients. Fresh, unforgettable — every bite.
          </p>

          <div className="flex flex-col sm:flex-row items-start gap-4">
            <a
              href="#menu"
              className="group flex items-center gap-3 bg-primary text-primary-foreground px-8 py-4 text-sm uppercase tracking-[0.2em] font-medium hover:bg-primary/90 transition-all duration-300"
            >
              Explore Our Menu
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#story"
              className="flex items-center gap-3 border border-border/50 text-foreground px-8 py-4 text-sm uppercase tracking-[0.2em] font-medium hover:border-primary/50 hover:text-primary transition-all duration-300"
            >
              Our Story
            </a>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Scroll</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <ChevronDown className="w-4 h-4 text-primary" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}