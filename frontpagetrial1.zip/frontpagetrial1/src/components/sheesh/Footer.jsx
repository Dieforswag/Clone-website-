import React from 'react';
import { MapPin, Clock, Phone, Mail, Instagram } from 'lucide-react';
import LiveFlame from './LiveFlame';

export default function Footer() {
  return (
    <footer id="locations" className="bg-secondary text-secondary-foreground">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20 md:py-28">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <h2 className="font-display text-3xl font-bold mb-2">
              Sheesh<span className="text-primary">.</span>
            </h2>
            <p className="text-secondary-foreground/70 text-sm font-body mb-6 leading-relaxed">
              Authentic Mediterranean cuisine crafted with passion and the finest ingredients.
            </p>
            <LiveFlame />
          </div>

          {/* Location 1 */}
          <div>
            <h3 className="font-display text-lg font-semibold mb-4">Falls Church</h3>
            <div className="space-y-3 text-sm text-secondary-foreground/70 font-body">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
                <span>8190 Strawberry Ln Unit 4,<br />Falls Church, VA 22042</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Daily 11:00 AM – 9:00 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <span>(703) 555-0123</span>
              </div>
            </div>
          </div>

          {/* Location 2 */}
          <div>
            <h3 className="font-display text-lg font-semibold mb-4">Chantilly</h3>
            <div className="space-y-3 text-sm text-secondary-foreground/70 font-body">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
                <span>13940 Lee Jackson Memorial Hwy,<br />Chantilly, VA 20151</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary flex-shrink-0" />
                <span>Daily 11:00 AM – 9:00 PM</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <span>(703) 555-0456</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display text-lg font-semibold mb-4">Quick Links</h3>
            <nav className="space-y-2 text-sm font-body">
              {['Menu', 'Our Story', 'Gallery', 'Catering', 'Reviews'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase().replace(' ', '-')}`}
                  className="block text-secondary-foreground/70 hover:text-primary transition-colors duration-300"
                >
                  {link}
                </a>
              ))}
            </nav>
            <div className="flex gap-3 mt-6">
              <a href="#" className="w-9 h-9 border border-secondary-foreground/20 flex items-center justify-center hover:border-primary hover:text-primary transition-all duration-300">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 border border-secondary-foreground/20 flex items-center justify-center hover:border-primary hover:text-primary transition-all duration-300">
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-secondary-foreground/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-secondary-foreground/50 font-body">
            © 2024 Sheesh Grill. All rights reserved.
          </p>
          <p className="text-xs text-secondary-foreground/50 font-body">
            Crafted with fire & passion
          </p>
        </div>
      </div>
    </footer>
  );
}