import React from 'react';

export default function LiveFlame() {
  return (
    <div className="flex items-center gap-2">
      <div className="relative w-4 h-5">
        <svg viewBox="0 0 16 20" className="w-full h-full animate-flicker">
          <path
            d="M8 0C8 0 2 6 2 11C2 14.5 4.5 17.5 8 18C11.5 17.5 14 14.5 14 11C14 6 8 0 8 0Z"
            fill="hsl(18, 100%, 50%)"
            opacity="0.9"
          />
          <path
            d="M8 6C8 6 5 9 5 12C5 14 6.5 15.5 8 16C9.5 15.5 11 14 11 12C11 9 8 6 8 6Z"
            fill="hsl(36, 100%, 60%)"
            opacity="0.8"
          />
          <path
            d="M8 10C8 10 7 11.5 7 13C7 14 7.5 14.5 8 15C8.5 14.5 9 14 9 13C9 11.5 8 10 8 10Z"
            fill="hsl(45, 100%, 80%)"
            opacity="0.9"
          />
        </svg>
      </div>
      <span className="text-xs uppercase tracking-[0.2em] text-primary font-body">Kitchen Active</span>
    </div>
  );
}