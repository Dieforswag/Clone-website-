import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const menuItems = [
  { name: 'Chicken Kabob Platter', price: '$16.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/7159c9347_generated_f864de9a.png', desc: 'Tender marinated chicken, charcoal-grilled to perfection' },
  { name: 'Beef Kubideh Platter', price: '$17.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/d5356a95c_generated_392c451f.png', desc: 'Hand-ground beef with saffron, grilled on open flame' },
  { name: 'Steak Kabob Platter', price: '$19.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/5b38727a1_generated_41e7220b.png', desc: 'Premium cut steak skewered with charred peppers' },
  { name: 'Beef & Lamb Gyro', price: '$14.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/a00ccbf12_generated_4f15bf45.png', desc: 'Slow-roasted beef and lamb, house-made tzatziki' },
  { name: 'Crispy Falafel', price: '$12.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/aaac381e9_generated_e1708b2a.png', desc: 'Golden chickpea falafel, tahini, fresh herbs' },
  { name: 'Chicken Shawarma', price: '$15.99', img: 'https://media.base44.com/images/public/6a007691428801536fd594d0/d87792d17_generated_41224f1f.png', desc: 'Rotisserie-carved chicken with garlic sauce' },
];

function MenuItem({ item, index }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.1 }}
      className="group relative"
    >
      <div className="relative overflow-hidden aspect-square bg-card">
        <img
          src={item.img}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {/* Sizzle glow on hover */}
        <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/10 transition-all duration-500" />
        <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-background to-transparent" />
      </div>
      <div className="pt-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-display text-xl font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
            {item.name}
          </h3>
          <span className="text-primary font-display text-lg font-semibold whitespace-nowrap">
            {item.price}
          </span>
        </div>
        <p className="text-sm text-muted-foreground font-body leading-relaxed">
          {item.desc}
        </p>
      </div>
    </motion.div>
  );
}

export default function FeaturedMenu() {
  const headerRef = useRef(null);
  const headerInView = useInView(headerRef, { once: true });

  return (
    <section id="menu" className="py-24 md:py-32 px-6 lg:px-10 max-w-7xl mx-auto">
      {/* Section Header */}
      <motion.div
        ref={headerRef}
        initial={{ opacity: 0, y: 30 }}
        animate={headerInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
        className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16"
      >
        <div>
          <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">The Menu</span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 leading-tight">
            Gallery of<br />
            <span className="italic font-normal text-secondary">Flavors</span>
          </h2>
        </div>
        <a
          href="#menu"
          className="group flex items-center gap-2 text-sm uppercase tracking-[0.15em] text-muted-foreground hover:text-primary transition-colors font-body"
        >
          View Full Menu
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </a>
      </motion.div>

      {/* Ember Line */}
      <div className="ember-line mb-16" />

      {/* Menu Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
        {menuItems.map((item, i) => (
          <MenuItem key={item.name} item={item} index={i} />
        ))}
      </div>
    </section>
  );
}