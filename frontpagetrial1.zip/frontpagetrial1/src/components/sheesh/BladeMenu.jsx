import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight } from 'lucide-react';

export default function BladeMenu({ isOpen, onClose, links }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-md z-[60]"
            onClick={onClose}
          />

          {/* Blade Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="fixed top-0 right-0 bottom-0 w-full sm:w-[420px] bg-card z-[70] border-l border-border/30 flex flex-col"
          >
            {/* Close */}
            <div className="flex justify-end p-6">
              <button onClick={onClose} className="text-foreground hover:text-primary transition-colors">
                <X className="w-7 h-7" />
              </button>
            </div>

            {/* Links */}
            <nav className="flex-1 flex flex-col justify-center px-10 gap-2">
              {links.map((link, i) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  onClick={onClose}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.15 + i * 0.06, duration: 0.5 }}
                  className="group flex items-center justify-between py-4 border-b border-border/20"
                >
                  <span className="font-display text-3xl md:text-4xl text-foreground group-hover:text-primary transition-colors duration-300">
                    {link.label}
                  </span>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-all duration-300 group-hover:translate-x-1" />
                </motion.a>
              ))}
            </nav>

            {/* Bottom CTA */}
            <div className="p-10">
              <a
                href="#menu"
                onClick={onClose}
                className="flex items-center justify-center gap-2 bg-primary text-primary-foreground py-4 text-sm uppercase tracking-[0.2em] font-medium hover:bg-primary/90 transition-all"
              >
                Order Online
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}