import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const GRILL_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/4d27dc557_generated_762de327.png';

export default function OrderSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="relative py-24 md:py-36 overflow-hidden">
      {/* Full-bleed background */}
      <div className="absolute inset-0">
        <img src={GRILL_IMG} alt="Glowing charcoal grill" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      </div>

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9 }}
        >
          <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">Convenience</span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 mb-6 leading-tight">
            Order From<br />
            <span className="italic font-normal text-secondary">Our Website</span>
          </h2>
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto leading-relaxed font-body mb-12">
            Craving something fresh and flavorful? Skip the wait and order directly. 
            Our online ordering is fast, simple, and secure — bringing your favorite dishes 
            straight to your door.
          </p>
          <a
            href="#menu"
            className="group inline-flex items-center gap-3 bg-primary text-primary-foreground px-10 py-5 text-sm uppercase tracking-[0.2em] font-medium hover:bg-primary/90 transition-all duration-300"
          >
            Order Now
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}