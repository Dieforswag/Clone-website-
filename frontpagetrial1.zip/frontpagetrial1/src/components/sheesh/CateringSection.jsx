import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const CATERING_IMG = 'https://media.base44.com/images/public/6a007691428801536fd594d0/3be50d597_generated_d1c6bcfb.png';

export default function CateringSection() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="catering" className="relative py-24 md:py-36 overflow-hidden">
      <div className="absolute inset-0">
        <img src={CATERING_IMG} alt="Mediterranean catering spread" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/40" />
      </div>

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9 }}
          className="max-w-xl"
        >
          <span className="text-primary text-sm uppercase tracking-[0.3em] font-body">Catering</span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mt-3 mb-6 leading-tight">
            Bring the Flavor<br />
            <span className="italic font-normal text-secondary">To Your Event</span>
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed font-body mb-10">
            Let Sheesh Grill cater your next gathering with bold, heart-healthy 
            Middle Eastern cuisine that everyone will love. Whether it's a corporate event, 
            wedding, or family celebration — fresh, customizable, and sure to impress.
          </p>
          <a
            href="#locations"
            className="group inline-flex items-center gap-3 bg-primary text-primary-foreground px-8 py-4 text-sm uppercase tracking-[0.2em] font-medium hover:bg-primary/90 transition-all duration-300"
          >
            Inquire Now
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}